package com.waza.api.client;

import java.util.*;
import com.waza.api.net.request.WewazRequest;
import com.waza.api.descriptor.RequestDescriptor;


/**
 * Class Context
 */
public class Context {

  //
  // Fields
  //

  private com.waza.api.descriptor.RequestDescriptor descriptor;
  
  //
  // Constructors
  //
  public Context () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of descriptor
   * @param newVar the new value of descriptor
   */
  public void setDescriptor (com.waza.api.descriptor.RequestDescriptor newVar) {
    descriptor = newVar;
  }

  /**
   * Get the value of descriptor
   * @return the value of descriptor
   */
  public com.waza.api.descriptor.RequestDescriptor getDescriptor () {
    return descriptor;
  }

  //
  // Other methods
  //

  /**
   * @return       List
   */
  public List invoke()
  {
  }


}
