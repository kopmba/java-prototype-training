package com.waza.api.client;

import java.util.*;


/**
 * Class CacheResource
 */
public class CacheResource {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public CacheResource () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       List
   * @param        key
   */
  public List get(String key)
  {
  }


  /**
   * @param        cache
   */
  public void create(com.waza.api.client.Cache cache)
  {
  }


  /**
   * @param        key
   * @param        predicat
   */
  public void getById(String key, String predicat)
  {
  }


  /**
   * @param        key
   * @param        predicat
   */
  public void update(String key, String predicat)
  {
  }


  /**
   * @param        predicat
   */
  public void remove(String predicat)
  {
  }


  /**
   */
  public void clear()
  {
  }


}
