package com.waza.api.client;

import java.util.*;


/**
 * Class Cache
 */
public class Cache {

  //
  // Fields
  //

  private String key;
  private String predicat;
  
  //
  // Constructors
  //
  public Cache () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of key
   * @param newVar the new value of key
   */
  public void setKey (String newVar) {
    key = newVar;
  }

  /**
   * Get the value of key
   * @return the value of key
   */
  public String getKey () {
    return key;
  }

  /**
   * Set the value of predicat
   * @param newVar the new value of predicat
   */
  public void setPredicat (String newVar) {
    predicat = newVar;
  }

  /**
   * Get the value of predicat
   * @return the value of predicat
   */
  public String getPredicat () {
    return predicat;
  }

  //
  // Other methods
  //

}
