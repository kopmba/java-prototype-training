package com.waza.api.descriptor;
import com.waza.api.client.Context;


/**
 * Class RequestDescriptor
 */
public class RequestDescriptor {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public RequestDescriptor () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        descriptor
   */
  public void configure(com.waza.api.descriptor.FileDescriptor descriptor)
  {
  }


  /**
   * @param        ctx
   */
  public void setContext(com.waza.api.client.Context ctx)
  {
  }


  /**
   * @return       object
   */
  public object load()
  {
  }


}
