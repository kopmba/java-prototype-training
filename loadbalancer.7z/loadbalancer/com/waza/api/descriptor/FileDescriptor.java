package com.waza.api.descriptor;


/**
 * Class FileDescriptor
 */
public class FileDescriptor {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public FileDescriptor () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       object
   */
  public object info()
  {
  }


}
