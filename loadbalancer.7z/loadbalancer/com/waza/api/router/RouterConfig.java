package com.waza.api.router;

import java.util.*;


/**
 * Class RouterConfig
 */
public class RouterConfig {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public RouterConfig () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        routes
   */
  public void config(List routes)
  {
  }


}
