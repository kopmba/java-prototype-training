package com.waza.api.router;

import java.util.*;


/**
 * Class Route
 */
public class Route {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Route () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       List
   * @param        server
   */
  public List routes(WewazServer server)
  {
  }


}
