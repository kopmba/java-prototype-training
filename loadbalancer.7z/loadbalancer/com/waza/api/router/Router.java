package com.waza.api.router;


/**
 * Interface Router
 */
public interface Router {

  //
  // Fields
  //

  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       List
   */
  public List find();


  /**
   * @return       object
   * @param        predicat
   */
  public object findOne(String predicat);


  /**
   */
  public void create();


  /**
   * @param        resource
   * @param        predicat
   */
  public void update(object resource, String predicat);


  /**
   * @param        predicat
   */
  public void remove(String predicat);


  /**
   * @return       List
   * @param        options
   */
  public List filter(object options);


}
