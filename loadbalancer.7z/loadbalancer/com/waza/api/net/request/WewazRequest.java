package com.waza.api.net.request;

import java.util.*;


/**
 * Interface WewazRequest
 */
public interface WewazRequest {

  //
  // Fields
  //

  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       boolean
   * @param        request
   */
  public boolean verify(com.waza.api.net.request.WewazRequest request);


  /**
   * @return       HttpHandler
   */
  public HttpHandler handle();


}
