package com.waza.api.net.request;
import com.waza.api.client.CacheResource;


/**
 * Class RequestRegister
 */
public class RequestRegister {

  //
  // Fields
  //

  private com.waza.api.client.CacheResource resource;
  
  //
  // Constructors
  //
  public RequestRegister () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of resource
   * @param newVar the new value of resource
   */
  public void setResource (com.waza.api.client.CacheResource newVar) {
    resource = newVar;
  }

  /**
   * Get the value of resource
   * @return the value of resource
   */
  public com.waza.api.client.CacheResource getResource () {
    return resource;
  }

  //
  // Other methods
  //

  /**
   * @param        url
   * @param        request
   */
  public void add(String url, com.waza.api.net.request.WewazRequest request)
  {
  }


  /**
   * @return       object
   * @param        request
   */
  public object get(com.waza.api.net.request.WewazRequest request)
  {
  }


}
