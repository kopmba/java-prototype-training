package com.waza.api.net.request;
import com.waza.api.router.Router;


/**
 * Class HttpRequest
 */
public class HttpRequest implements WewazRequest, WewazRequest, Router {

  //
  // Fields
  //

  private com.waza.api.net.request.RequestRegister register;
  
  //
  // Constructors
  //
  public HttpRequest () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of register
   * @param newVar the new value of register
   */
  public void setRegister (com.waza.api.net.request.RequestRegister newVar) {
    register = newVar;
  }

  /**
   * Get the value of register
   * @return the value of register
   */
  public com.waza.api.net.request.RequestRegister getRegister () {
    return register;
  }

  //
  // Other methods
  //

  /**
   * @return       boolean
   * @param        request
   */
  abstract public boolean verify(com.waza.api.net.request.WewazRequest request);


  /**
   * @return       HttpHandler
   */
  abstract public HttpHandler handle();


  /**
   * @return       List
   */
  abstract public List find();


  /**
   * @return       object
   * @param        predicat
   */
  abstract public object findOne(String predicat);


  /**
   */
  abstract public void create();


  /**
   * @param        resource
   * @param        predicat
   */
  abstract public void update(object resource, String predicat);


  /**
   * @param        predicat
   */
  abstract public void remove(String predicat);


  /**
   * @return       List
   * @param        options
   */
  abstract public List filter(object options);


}
