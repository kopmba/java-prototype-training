
import java.util.*;
import com.waza.api.client.Context;
import com.waza.api.router.RouterConfig;


/**
 * Class WewazServer
 */
public class WewazServer {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public WewazServer () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        ctx
   * @param        port
   */
  public void start(com.waza.api.client.Context ctx, int port)
  {
  }


  /**
   * @param        ctx
   */
  public void load(com.waza.api.client.Context ctx)
  {
  }


  /**
   * @return       com.waza.api.router.RouterConfig
   * @param        server
   */
  public com.waza.api.router.RouterConfig createRouter(WewazServer server)
  {
  }


}
