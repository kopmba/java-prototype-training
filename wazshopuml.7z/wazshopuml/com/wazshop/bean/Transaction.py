# coding=System

class Transaction(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  id  (private)

   

  info  (private)

   

  creation_date  (private)

  """



