#
# 
#

class Collection
  #
  # Accessor Methods
  #


  public

  protected

  private

end

