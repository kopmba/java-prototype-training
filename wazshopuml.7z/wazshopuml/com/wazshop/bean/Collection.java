package com.wazshop.bean;


/**
 * Class Collection
 */
public class Collection {

  //
  // Fields
  //

  private String name;
  private string[] fields;
  private map<string, object> bean;
  
  //
  // Constructors
  //
  public Collection () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of name
   * @param newVar the new value of name
   */
  public void setName (String newVar) {
    name = newVar;
  }

  /**
   * Get the value of name
   * @return the value of name
   */
  public String getName () {
    return name;
  }

  /**
   * Set the value of fields
   * @param newVar the new value of fields
   */
  public void setFields (string[] newVar) {
    fields = newVar;
  }

  /**
   * Get the value of fields
   * @return the value of fields
   */
  public string[] getFields () {
    return fields;
  }

  /**
   * Set the value of bean
   * @param newVar the new value of bean
   */
  public void setBean (map<string, object> newVar) {
    bean = newVar;
  }

  /**
   * Get the value of bean
   * @return the value of bean
   */
  public map<string, object> getBean () {
    return bean;
  }

  //
  // Other methods
  //

}
