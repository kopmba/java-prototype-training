#
# 
#

class DB
  #
  # Accessor Methods
  #


  public

  protected

  private

end

