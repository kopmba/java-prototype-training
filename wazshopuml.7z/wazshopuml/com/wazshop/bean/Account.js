#include "com/wazshop/bean/Account.js"


/**
  * class Account
  * 
  */

Account = function ()
{
  this._init ();
}


/**
 * _init sets all Account attributes to their default value. Make sure to call this
 * method within your class constructor
 */
Account.prototype._init = function ()
{
  /**
   * 
   */
  this.m_username = "";
  /**
   * 
   */
  this.m_password = "";
  /**
   * 
   */
  this.m_email = "";
  /**
   * 
   */
  this.m_token = "";

  /**Aggregations: */

  /**Compositions: */

}


