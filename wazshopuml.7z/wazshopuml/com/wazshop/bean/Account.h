
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>


namespace com_wazshop_bean {


/**
  * class Account
  * 
  */

class Account
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Account();

  /**
   * Empty Destructor
   */
  virtual ~Account();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  std::string username;
  std::string password;
  std::string email;
  std::string token;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of username
   * @param value the new value of username
   */
  void setUsername(std::string value)
  {
    username = value;
  }

  /**
   * Get the value of username
   * @return the value of username
   */
  std::string getUsername()
  {
    return username;
  }

  /**
   * Set the value of password
   * @param value the new value of password
   */
  void setPassword(std::string value)
  {
    password = value;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  std::string getPassword()
  {
    return password;
  }

  /**
   * Set the value of email
   * @param value the new value of email
   */
  void setEmail(std::string value)
  {
    email = value;
  }

  /**
   * Get the value of email
   * @return the value of email
   */
  std::string getEmail()
  {
    return email;
  }

  /**
   * Set the value of token
   * @param value the new value of token
   */
  void setToken(std::string value)
  {
    token = value;
  }

  /**
   * Get the value of token
   * @return the value of token
   */
  std::string getToken()
  {
    return token;
  }

  void initAttributes();

};
} // end of package namespace

#endif // ACCOUNT_H
