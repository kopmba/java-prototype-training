<?php


/**
 * class Collection
 * 
 */
class Collection
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $name;

  /**
   * 
   * @access private
   */
  private $fields;

  /**
   * 
   * @access private
   */
  private $bean;






} // end of Collection
?>
