#include "DB.h"

// Constructors/Destructors
//  

DB::DB()
{
  initAttributes();
}

DB::~DB()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void DB::initAttributes()
{
}

