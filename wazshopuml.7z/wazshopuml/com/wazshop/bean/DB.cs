using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;


namespace com.wazshop.bean
{

  /// <summary>
  /// 
  /// </summary>
  public class DB
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private string name;


    /// <summary>
    /// 
    /// </summary>
    private string username;


    /// <summary>
    /// 
    /// </summary>
    private string password;


    /// <summary>
    /// 
    /// </summary>
    private string servername;


    /// <summary>
    /// 
    /// </summary>
    private string url;


    /// <summary>
    /// 
    /// </summary>
    private string host;


    /// <summary>
    /// 
    /// </summary>
    private int port;


    /// <summary>
    /// 
    /// </summary>
    private Account account;



    #endregion


    #region Public methods

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.bean

