# coding=System

class Collection(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  name  (private)

   

  fields  (private)

   

  bean  (private)

  """



