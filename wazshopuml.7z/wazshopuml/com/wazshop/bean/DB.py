# coding=System
from com.wazshop.bean.DB import *
from com.wazshop.bean.Account import *

class DB(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  name  (private)

   

  username  (private)

   

  password  (private)

   

  servername  (private)

   

  url  (private)

   

  host  (private)

   

  port  (private)

   

  account  (private)

  """



