#include "Collection.h"

// Constructors/Destructors
//  

Collection::Collection()
{
  initAttributes();
}

Collection::~Collection()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Collection::initAttributes()
{
}

