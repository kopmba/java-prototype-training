<?php
require_once 'com/wazshop/bean/Account.php';


/**
 * class Account
 * 
 */
class Account
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $username;

  /**
   * 
   * @access private
   */
  private $password;

  /**
   * 
   * @access private
   */
  private $email;

  /**
   * 
   * @access private
   */
  private $token;






} // end of Account
?>
