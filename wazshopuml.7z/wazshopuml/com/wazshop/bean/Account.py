# coding=System
from com.wazshop.bean.Account import *

class Account(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  username  (private)

   

  password  (private)

   

  email  (private)

   

  token  (private)

  """



