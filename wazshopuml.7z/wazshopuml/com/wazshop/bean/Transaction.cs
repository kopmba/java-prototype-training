using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace com.wazshop.bean
{

  /// <summary>
  /// 
  /// </summary>
  public class Transaction
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private string id;


    /// <summary>
    /// 
    /// </summary>
    private map<string, object> info;


    /// <summary>
    /// 
    /// </summary>
    private string creation_date;



    #endregion


    #region Public methods

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.bean

