package com.wazshop.bean;


/**
 * Class Transaction
 */
public class Transaction {

  //
  // Fields
  //

  private String id;
  private map<string, object> info;
  private String creation_date;
  
  //
  // Constructors
  //
  public Transaction () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of id
   * @param newVar the new value of id
   */
  public void setId (String newVar) {
    id = newVar;
  }

  /**
   * Get the value of id
   * @return the value of id
   */
  public String getId () {
    return id;
  }

  /**
   * Set the value of info
   * @param newVar the new value of info
   */
  public void setInfo (map<string, object> newVar) {
    info = newVar;
  }

  /**
   * Get the value of info
   * @return the value of info
   */
  public map<string, object> getInfo () {
    return info;
  }

  /**
   * Set the value of creation_date
   * @param newVar the new value of creation_date
   */
  public void setCreation_date (String newVar) {
    creation_date = newVar;
  }

  /**
   * Get the value of creation_date
   * @return the value of creation_date
   */
  public String getCreation_date () {
    return creation_date;
  }

  //
  // Other methods
  //

}
