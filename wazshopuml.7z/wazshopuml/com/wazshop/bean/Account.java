package com.wazshop.bean;


/**
 * Class Account
 */
public class Account {

  //
  // Fields
  //

  private String username;
  private String password;
  private String email;
  private String token;
  
  //
  // Constructors
  //
  public Account () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of username
   * @param newVar the new value of username
   */
  public void setUsername (String newVar) {
    username = newVar;
  }

  /**
   * Get the value of username
   * @return the value of username
   */
  public String getUsername () {
    return username;
  }

  /**
   * Set the value of password
   * @param newVar the new value of password
   */
  public void setPassword (String newVar) {
    password = newVar;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  public String getPassword () {
    return password;
  }

  /**
   * Set the value of email
   * @param newVar the new value of email
   */
  public void setEmail (String newVar) {
    email = newVar;
  }

  /**
   * Get the value of email
   * @return the value of email
   */
  public String getEmail () {
    return email;
  }

  /**
   * Set the value of token
   * @param newVar the new value of token
   */
  public void setToken (String newVar) {
    token = newVar;
  }

  /**
   * Get the value of token
   * @return the value of token
   */
  public String getToken () {
    return token;
  }

  //
  // Other methods
  //

}
