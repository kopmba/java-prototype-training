using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;


namespace com.wazshop.bean
{

  /// <summary>
  /// 
  /// </summary>
  public class Account
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private string username;


    /// <summary>
    /// 
    /// </summary>
    private string password;


    /// <summary>
    /// 
    /// </summary>
    private string email;


    /// <summary>
    /// 
    /// </summary>
    private string token;



    #endregion


    #region Public methods

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.bean

