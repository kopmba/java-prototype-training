
#ifndef DB_H
#define DB_H

#include <string>


namespace com_wazshop_bean {


/**
  * class DB
  * 
  */

class DB
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  DB();

  /**
   * Empty Destructor
   */
  virtual ~DB();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  std::string name;
  std::string username;
  std::string password;
  std::string servername;
  std::string url;
  std::string host;
  int port;
  com.wazshop.bean::Account account;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of name
   * @param value the new value of name
   */
  void setName(std::string value)
  {
    name = value;
  }

  /**
   * Get the value of name
   * @return the value of name
   */
  std::string getName()
  {
    return name;
  }

  /**
   * Set the value of username
   * @param value the new value of username
   */
  void setUsername(std::string value)
  {
    username = value;
  }

  /**
   * Get the value of username
   * @return the value of username
   */
  std::string getUsername()
  {
    return username;
  }

  /**
   * Set the value of password
   * @param value the new value of password
   */
  void setPassword(std::string value)
  {
    password = value;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  std::string getPassword()
  {
    return password;
  }

  /**
   * Set the value of servername
   * @param value the new value of servername
   */
  void setServername(std::string value)
  {
    servername = value;
  }

  /**
   * Get the value of servername
   * @return the value of servername
   */
  std::string getServername()
  {
    return servername;
  }

  /**
   * Set the value of url
   * @param value the new value of url
   */
  void setUrl(std::string value)
  {
    url = value;
  }

  /**
   * Get the value of url
   * @return the value of url
   */
  std::string getUrl()
  {
    return url;
  }

  /**
   * Set the value of host
   * @param value the new value of host
   */
  void setHost(std::string value)
  {
    host = value;
  }

  /**
   * Get the value of host
   * @return the value of host
   */
  std::string getHost()
  {
    return host;
  }

  /**
   * Set the value of port
   * @param value the new value of port
   */
  void setPort(int value)
  {
    port = value;
  }

  /**
   * Get the value of port
   * @return the value of port
   */
  int getPort()
  {
    return port;
  }

  /**
   * Set the value of account
   * @param value the new value of account
   */
  void setAccount(com.wazshop.bean::Account value)
  {
    account = value;
  }

  /**
   * Get the value of account
   * @return the value of account
   */
  com.wazshop.bean::Account getAccount()
  {
    return account;
  }

  void initAttributes();

};
} // end of package namespace

#endif // DB_H
