#include "Transaction.h"

// Constructors/Destructors
//  

Transaction::Transaction()
{
  initAttributes();
}

Transaction::~Transaction()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Transaction::initAttributes()
{
}

