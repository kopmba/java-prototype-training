<?php


/**
 * class Transaction
 * 
 */
class Transaction
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $id;

  /**
   * 
   * @access private
   */
  private $info;

  /**
   * 
   * @access private
   */
  private $creation_date;






} // end of Transaction
?>
