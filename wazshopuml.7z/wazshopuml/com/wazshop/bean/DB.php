<?php
require_once 'com/wazshop/bean/DB.php';
require_once 'com/wazshop/bean/Account.php';


/**
 * class DB
 * 
 */
class DB
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $name;

  /**
   * 
   * @access private
   */
  private $username;

  /**
   * 
   * @access private
   */
  private $password;

  /**
   * 
   * @access private
   */
  private $servername;

  /**
   * 
   * @access private
   */
  private $url;

  /**
   * 
   * @access private
   */
  private $host;

  /**
   * 
   * @access private
   */
  private $port;

  /**
   * 
   * @access private
   */
  private $account;






} // end of DB
?>
