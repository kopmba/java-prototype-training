package com.wazshop.bean;


/**
 * Class DB
 */
public class DB {

  //
  // Fields
  //

  private String name;
  private String username;
  private String password;
  private String servername;
  private String url;
  private String host;
  private int port;
  private com.wazshop.bean.Account account;
  
  //
  // Constructors
  //
  public DB () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of name
   * @param newVar the new value of name
   */
  public void setName (String newVar) {
    name = newVar;
  }

  /**
   * Get the value of name
   * @return the value of name
   */
  public String getName () {
    return name;
  }

  /**
   * Set the value of username
   * @param newVar the new value of username
   */
  public void setUsername (String newVar) {
    username = newVar;
  }

  /**
   * Get the value of username
   * @return the value of username
   */
  public String getUsername () {
    return username;
  }

  /**
   * Set the value of password
   * @param newVar the new value of password
   */
  public void setPassword (String newVar) {
    password = newVar;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  public String getPassword () {
    return password;
  }

  /**
   * Set the value of servername
   * @param newVar the new value of servername
   */
  public void setServername (String newVar) {
    servername = newVar;
  }

  /**
   * Get the value of servername
   * @return the value of servername
   */
  public String getServername () {
    return servername;
  }

  /**
   * Set the value of url
   * @param newVar the new value of url
   */
  public void setUrl (String newVar) {
    url = newVar;
  }

  /**
   * Get the value of url
   * @return the value of url
   */
  public String getUrl () {
    return url;
  }

  /**
   * Set the value of host
   * @param newVar the new value of host
   */
  public void setHost (String newVar) {
    host = newVar;
  }

  /**
   * Get the value of host
   * @return the value of host
   */
  public String getHost () {
    return host;
  }

  /**
   * Set the value of port
   * @param newVar the new value of port
   */
  public void setPort (int newVar) {
    port = newVar;
  }

  /**
   * Get the value of port
   * @return the value of port
   */
  public int getPort () {
    return port;
  }

  /**
   * Set the value of account
   * @param newVar the new value of account
   */
  public void setAccount (com.wazshop.bean.Account newVar) {
    account = newVar;
  }

  /**
   * Get the value of account
   * @return the value of account
   */
  public com.wazshop.bean.Account getAccount () {
    return account;
  }

  //
  // Other methods
  //

}
