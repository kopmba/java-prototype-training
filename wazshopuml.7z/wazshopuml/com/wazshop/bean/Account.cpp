#include "Account.h"

// Constructors/Destructors
//  

Account::Account()
{
  initAttributes();
}

Account::~Account()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void Account::initAttributes()
{
}

