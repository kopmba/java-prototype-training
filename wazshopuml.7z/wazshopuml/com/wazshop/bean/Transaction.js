

/**
  * class Transaction
  * 
  */

Transaction = function ()
{
  this._init ();
}


/**
 * _init sets all Transaction attributes to their default value. Make sure to call
 * this method within your class constructor
 */
Transaction.prototype._init = function ()
{
  /**
   * 
   */
  this.m_id = "";
  /**
   * 
   */
  this.m_info = "";
  /**
   * 
   */
  this.m_creation_date = "";

  /**Aggregations: */

  /**Compositions: */

}


