#
# 
#

class Transaction
  #
  # Accessor Methods
  #


  public

  protected

  private

end

