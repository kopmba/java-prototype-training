
#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>


namespace com_wazshop_bean {


/**
  * class Transaction
  * 
  */

class Transaction
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Transaction();

  /**
   * Empty Destructor
   */
  virtual ~Transaction();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  std::string id;
  map<string, object> info;
  std::string creation_date;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of id
   * @param value the new value of id
   */
  void setId(std::string value)
  {
    id = value;
  }

  /**
   * Get the value of id
   * @return the value of id
   */
  std::string getId()
  {
    return id;
  }

  /**
   * Set the value of info
   * @param value the new value of info
   */
  void setInfo(map<string, object> value)
  {
    info = value;
  }

  /**
   * Get the value of info
   * @return the value of info
   */
  map<string, object> getInfo()
  {
    return info;
  }

  /**
   * Set the value of creation_date
   * @param value the new value of creation_date
   */
  void setCreation_date(std::string value)
  {
    creation_date = value;
  }

  /**
   * Get the value of creation_date
   * @return the value of creation_date
   */
  std::string getCreation_date()
  {
    return creation_date;
  }

  void initAttributes();

};
} // end of package namespace

#endif // TRANSACTION_H
