

/**
  * class Collection
  * 
  */

Collection = function ()
{
  this._init ();
}


/**
 * _init sets all Collection attributes to their default value. Make sure to call
 * this method within your class constructor
 */
Collection.prototype._init = function ()
{
  /**
   * 
   */
  this.m_name = "";
  /**
   * 
   */
  this.m_fields = "";
  /**
   * 
   */
  this.m_bean = "";

  /**Aggregations: */

  /**Compositions: */

}


