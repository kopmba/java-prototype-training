
#ifndef COLLECTION_H
#define COLLECTION_H

#include <string>


namespace com_wazshop_bean {


/**
  * class Collection
  * 
  */

class Collection
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Collection();

  /**
   * Empty Destructor
   */
  virtual ~Collection();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  std::string name;
  string fields[];
  map<string, object> bean;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of name
   * @param value the new value of name
   */
  void setName(std::string value)
  {
    name = value;
  }

  /**
   * Get the value of name
   * @return the value of name
   */
  std::string getName()
  {
    return name;
  }

  /**
   * Set the value of fields
   * @param value the new value of fields
   */
  void setFields(string value[])
  {
    *fields = *value;
  }

  /**
   * Get the value of fields
   * @return the value of fields
   */
  string* getFields()
  {
    return fields;
  }

  /**
   * Set the value of bean
   * @param value the new value of bean
   */
  void setBean(map<string, object> value)
  {
    bean = value;
  }

  /**
   * Get the value of bean
   * @return the value of bean
   */
  map<string, object> getBean()
  {
    return bean;
  }

  void initAttributes();

};
} // end of package namespace

#endif // COLLECTION_H
