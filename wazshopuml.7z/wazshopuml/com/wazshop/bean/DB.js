#include "com/wazshop/bean/DB.js"
#include "com/wazshop/bean/Account.js"


/**
  * class DB
  * 
  */

DB = function ()
{
  this._init ();
}


/**
 * _init sets all DB attributes to their default value. Make sure to call this
 * method within your class constructor
 */
DB.prototype._init = function ()
{
  /**
   * 
   */
  this.m_name = "";
  /**
   * 
   */
  this.m_username = "";
  /**
   * 
   */
  this.m_password = "";
  /**
   * 
   */
  this.m_servername = "";
  /**
   * 
   */
  this.m_url = "";
  /**
   * 
   */
  this.m_host = "";
  /**
   * 
   */
  this.m_port = "";
  /**
   * 
   */
  this.m_account = "";

  /**Aggregations: */

  /**Compositions: */

}


