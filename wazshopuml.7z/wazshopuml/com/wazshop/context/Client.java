package com.wazshop.context;


/**
 * Class Client
 */
public class Client {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Client () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        tpl
   * @param        data
   */
  public void render(String tpl, object data)
  {
  }


}
