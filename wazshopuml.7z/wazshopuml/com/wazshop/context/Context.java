package com.wazshop.context;


/**
 * Class Context
 */
public class Context {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Context () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        colname
   * @param        method_option
   */
  public void addHandler(String colname, String method_option)
  {
  }


}
