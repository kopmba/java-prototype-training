

/**
  * class Client
  * 
  */

Client = function ()
{
  this._init ();
}


/**
 * _init sets all Client attributes to their default value. Make sure to call this
 * method within your class constructor
 */
Client.prototype._init = function ()
{

  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param tpl
    *      
 * @param data
    *      
 */
Client.prototype.render = function (tpl, data)
{
  
}



