<?php


/**
 * class Context
 * 
 */
class Context
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/


  /**
   * 
   *
   * @param string colname 

   * @param string method_option 

   * @return void
   * @access public
   */
  public function addHandler( $colname,  $method_option) {
  } // end of member function addHandler





} // end of Context
?>
