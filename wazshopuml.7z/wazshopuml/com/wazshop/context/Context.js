

/**
  * class Context
  * 
  */

Context = function ()
{
  this._init ();
}


/**
 * _init sets all Context attributes to their default value. Make sure to call this
 * method within your class constructor
 */
Context.prototype._init = function ()
{

  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param colname
    *      
 * @param method_option
    *      
 */
Context.prototype.addHandler = function (colname, method_option)
{
  
}



