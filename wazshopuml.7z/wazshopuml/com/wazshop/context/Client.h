
#ifndef CLIENT_H
#define CLIENT_H

#include <string>


namespace com_wazshop_context {


/**
  * class Client
  * 
  */

class Client
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Client();

  /**
   * Empty Destructor
   */
  virtual ~Client();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  tpl
   * @param  data
   */
  void render(std::string tpl, object data)
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  


  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // CLIENT_H
