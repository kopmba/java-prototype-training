
#ifndef CONTEXT_H
#define CONTEXT_H

#include <string>


namespace com_wazshop_context {


/**
  * class Context
  * 
  */

class Context
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Context();

  /**
   * Empty Destructor
   */
  virtual ~Context();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  colname
   * @param  method_option
   */
  void addHandler(std::string colname, std::string method_option)
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  


  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // CONTEXT_H
