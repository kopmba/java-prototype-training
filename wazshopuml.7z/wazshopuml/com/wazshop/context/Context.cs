using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace com.wazshop.context
{

  /// <summary>
  /// 
  /// </summary>
  public class Context
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes


    #endregion


    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="colname"></param>
    /// <param name="method_option"></param>
    /// <returns></returns>
    public void addHandler(string colname, string method_option)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.context

