#
# 
#

class Context
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _colname_ string
  # * _method_option_ string
  def addHandler(colname, method_option)
    
  end

  protected

  private

end

