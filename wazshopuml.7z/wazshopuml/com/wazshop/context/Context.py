# coding=System

class Context(object):

  """
   

  :version:
  :author:
  """

  def addHandler(self, colname, method_option):
    """
     

    @param string colname : 
    @param string method_option : 
    @return  :
    @author
    """
    pass



