# coding=System

class Client(object):

  """
   

  :version:
  :author:
  """

  def render(self, tpl, data):
    """
     

    @param string tpl : 
    @param object data : 
    @return  :
    @author
    """
    pass



