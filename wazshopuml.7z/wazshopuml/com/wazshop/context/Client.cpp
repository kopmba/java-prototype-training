#include "Client.h"

// Constructors/Destructors
//  

Client::Client()
{
}

Client::~Client()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


