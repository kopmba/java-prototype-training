<?php


/**
 * class Client
 * 
 */
class Client
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/


  /**
   * 
   *
   * @param string tpl 

   * @param object data 

   * @return void
   * @access public
   */
  public function render( $tpl,  $data) {
  } // end of member function render





} // end of Client
?>
