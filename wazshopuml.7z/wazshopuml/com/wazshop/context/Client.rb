#
# 
#

class Client
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _tpl_ string
  # * _data_ object
  def render(tpl, data)
    
  end

  protected

  private

end

