using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace com.wazshop.context
{

  /// <summary>
  /// 
  /// </summary>
  public class Client
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes


    #endregion


    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="tpl"></param>
    /// <param name="data"></param>
    /// <returns></returns>
    public void render(string tpl, object data)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.context

