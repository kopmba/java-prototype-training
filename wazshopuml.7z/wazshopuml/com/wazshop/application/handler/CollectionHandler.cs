using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using com.wazshop.context;
using com.wazshop.config;

namespace com.wazshop.application.handler
{

  /// <summary>
  /// 
  /// </summary>
  public class CollectionHandler : , ApplicationHandler
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private RouterConfig router;



    #endregion


    #region ApplicationHandler members

    /// <summary>
    /// 
    /// </summary>
    /// <returns>HttpHandler</returns>
    abstract public HttpHandler create();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>HttpHandler</returns>
    abstract public HttpHandler get(string id);

    /// <summary>
    /// 
    /// </summary>
    /// <returns>HttpHandler</returns>
    abstract public HttpHandler get();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <param name="bean"></param>
    /// <returns>HttpHandler</returns>
    abstract public HttpHandler update(string id, com.wazshop.bean.Collection bean);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>HttpHandler</returns>
    abstract public HttpHandler remove(string id);

    #endregion


    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public void create(string name)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns>List</returns>
    public List get()
    {
      throw new Exception("The method or operation is not implemented.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="client"></param>
    /// <param name="view"></param>
    /// <param name="model"></param>
    /// <returns></returns>
    public void modelAndView(Client client, string view, object model)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.application.handler

