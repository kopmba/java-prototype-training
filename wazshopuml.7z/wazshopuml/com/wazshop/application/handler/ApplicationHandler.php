<?php
require_once 'com/wazshop/bean/Collection.php';


/**
 * class ApplicationHandler
 * 
 */
interface ApplicationHandler
{

  /** Aggregations: */

  /** Compositions: */

  /**
   * 
   *
   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function create();

  /**
   * 
   *
   * @param string id 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function get( $id);

  /**
   * 
   *
   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function get();

  /**
   * 
   *
   * @param string id 

   * @param com.wazshop.bean::Collection bean 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function update( $id,  $bean);

  /**
   * 
   *
   * @param string id 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function remove( $id);





} // end of ApplicationHandler
?>
