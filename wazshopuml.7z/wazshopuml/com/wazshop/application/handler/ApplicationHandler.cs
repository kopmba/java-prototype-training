using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using com.wazshop.bean;

namespace com.wazshop.application.handler
{

  /// <summary>
  /// 
  /// </summary>
  public interface ApplicationHandler
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <returns>HttpHandler</returns>
    HttpHandler create();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>HttpHandler</returns>
    HttpHandler get(string id);

    /// <summary>
    /// 
    /// </summary>
    /// <returns>HttpHandler</returns>
    HttpHandler get();

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <param name="bean"></param>
    /// <returns>HttpHandler</returns>
    HttpHandler update(string id, Collection bean);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id"></param>
    /// <returns>HttpHandler</returns>
    HttpHandler remove(string id);

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.application.handler

