package com.wazshop.application.handler;
import com.wazshop.context.Client;
import com.wazshop.config.RouterConfig;


/**
 * Class CollectionHandler
 */
public class CollectionHandler implements ApplicationHandler {

  //
  // Fields
  //

  private com.wazshop.config.RouterConfig router;
  
  //
  // Constructors
  //
  public CollectionHandler () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of router
   * @param newVar the new value of router
   */
  public void setRouter (com.wazshop.config.RouterConfig newVar) {
    router = newVar;
  }

  /**
   * Get the value of router
   * @return the value of router
   */
  public com.wazshop.config.RouterConfig getRouter () {
    return router;
  }

  //
  // Other methods
  //

  /**
   * @param        name
   */
  public void create(String name)
  {
  }


  /**
   * @return       List
   */
  public List get()
  {
  }


  /**
   * @param        client
   * @param        view
   * @param        model
   */
  public void modelAndView(com.wazshop.context.Client client, String view, object model)
  {
  }


  /**
   * @return       HttpHandler
   */
  abstract public HttpHandler create();


  /**
   * @return       HttpHandler
   * @param        id
   */
  abstract public HttpHandler get(String id);


  /**
   * @return       HttpHandler
   * @param        id
   * @param        bean
   */
  abstract public HttpHandler update(String id, com.wazshop.bean.Collection bean);


  /**
   * @return       HttpHandler
   * @param        id
   */
  abstract public HttpHandler remove(String id);


}
