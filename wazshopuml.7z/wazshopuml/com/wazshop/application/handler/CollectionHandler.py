# coding=System
from com_wazshop_application_handler.ApplicationHandler import *
from com.wazshop.application.handler.ApplicationHandler import *
from com.wazshop.context.Client import *
from com.wazshop.config.RouterConfig import *

class CollectionHandler (ApplicationHandler):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  router  (private)

  """

  def create(self, name):
    """
     

    @param string name : 
    @return  :
    @author
    """
    pass

  def get(self):
    """
     

    @return List :
    @author
    """
    pass

  def modelAndView(self, client, view, model):
    """
     

    @param com.wazshop.context.Client client : 
    @param string view : 
    @param object model : 
    @return  :
    @author
    """
    pass



