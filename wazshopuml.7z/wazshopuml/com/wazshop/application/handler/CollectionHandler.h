
#ifndef COLLECTIONHANDLER_H
#define COLLECTIONHANDLER_H

#include "com/wazshop/application/handler/ApplicationHandler.h"

#include <string>


namespace com_wazshop_application_handler {


/**
  * class CollectionHandler
  * 
  */

class CollectionHandler : virtual public ApplicationHandler
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  CollectionHandler();

  /**
   * Empty Destructor
   */
  virtual ~CollectionHandler();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  name
   */
  void create(std::string name)
  {
  }


  /**
   * @return List
   */
  List get()
  {
  }


  /**
   * @param  client
   * @param  view
   * @param  model
   */
  void modelAndView(com.wazshop.context::Client client, std::string view, object model)
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  com.wazshop.config::RouterConfig router;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of router
   * @param value the new value of router
   */
  void setRouter(com.wazshop.config::RouterConfig value)
  {
    router = value;
  }

  /**
   * Get the value of router
   * @return the value of router
   */
  com.wazshop.config::RouterConfig getRouter()
  {
    return router;
  }

  void initAttributes();

};
} // end of package namespace

#endif // COLLECTIONHANDLER_H
