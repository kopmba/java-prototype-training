#
# 
#

class CollectionHandler < ApplicationHandler

  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _name_ string
  def create(name)
    
  end

  #
  # 
  # * _returns_ List
  def get()
    
  end

  #
  # 
  # * _client_ com_wazshop_context_Client
  # * _view_ string
  # * _model_ object
  def modelAndView(client, view, model)
    
  end

  protected

  private

end

