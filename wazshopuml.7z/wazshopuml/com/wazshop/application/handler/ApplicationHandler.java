package com.wazshop.application.handler;
import com.wazshop.bean.Collection;


/**
 * Interface ApplicationHandler
 */
public interface ApplicationHandler {

  //
  // Fields
  //

  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       HttpHandler
   */
  public HttpHandler create();


  /**
   * @return       HttpHandler
   * @param        id
   */
  public HttpHandler get(String id);


  /**
   * @return       HttpHandler
   */
  public HttpHandler get();


  /**
   * @return       HttpHandler
   * @param        id
   * @param        bean
   */
  public HttpHandler update(String id, com.wazshop.bean.Collection bean);


  /**
   * @return       HttpHandler
   * @param        id
   */
  public HttpHandler remove(String id);


}
