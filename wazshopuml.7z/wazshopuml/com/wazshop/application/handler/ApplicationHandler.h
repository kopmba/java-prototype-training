
#ifndef APPLICATIONHANDLER_H
#define APPLICATIONHANDLER_H

#include <string>


namespace com_wazshop_application_handler {


/**
  * class ApplicationHandler
  * 
  */

class ApplicationHandler
{
public:
  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @return HttpHandler
   */
  virtual HttpHandler create() = 0;


  /**
   * @return HttpHandler
   * @param  id
   */
  virtual HttpHandler get(std::string id) = 0;


  /**
   * @return HttpHandler
   */
  virtual HttpHandler get() = 0;


  /**
   * @return HttpHandler
   * @param  id
   * @param  bean
   */
  virtual HttpHandler update(std::string id, com.wazshop.bean::Collection bean) = 0;


  /**
   * @return HttpHandler
   * @param  id
   */
  virtual HttpHandler remove(std::string id) = 0;

protected:
  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // APPLICATIONHANDLER_H
