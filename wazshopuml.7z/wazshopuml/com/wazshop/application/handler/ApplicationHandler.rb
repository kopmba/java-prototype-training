#
# 
#

class ApplicationHandler
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _returns_ HttpHandler
  def create()
    
  end

  #
  # 
  # * _id_ string
  # * _returns_ HttpHandler
  def get(id)
    
  end

  #
  # 
  # * _returns_ HttpHandler
  def get()
    
  end

  #
  # 
  # * _id_ string
  # * _bean_ com_wazshop_bean_Collection
  # * _returns_ HttpHandler
  def update(id, bean)
    
  end

  #
  # 
  # * _id_ string
  # * _returns_ HttpHandler
  def remove(id)
    
  end

  protected

  private

end

