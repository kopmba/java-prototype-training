#include "com/wazshop/bean/Collection.js"


/**
  * class ApplicationHandler
  * 
  */

ApplicationHandler = function ()
{
  this._init ();
}



  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 */
ApplicationHandler.prototype.create = function ()
{
  
}


/**
 * 
 * @param id
    *      
 */
ApplicationHandler.prototype.get = function (id)
{
  
}


/**
 * 
 */
ApplicationHandler.prototype.get = function ()
{
  
}


/**
 * 
 * @param id
    *      
 * @param bean
    *      
 */
ApplicationHandler.prototype.update = function (id, bean)
{
  
}


/**
 * 
 * @param id
    *      
 */
ApplicationHandler.prototype.remove = function (id)
{
  
}



