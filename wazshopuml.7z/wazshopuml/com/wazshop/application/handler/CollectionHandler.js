#include "com/wazshop/application/handler/ApplicationHandler.js"
#include "com/wazshop/context/Client.js"
#include "com/wazshop/config/RouterConfig.js"


/**
  * class CollectionHandler
  * 
  */

CollectionHandler = function ()
{
  this._init ();
}

CollectionHandler.prototype = new ApplicationHandler ();

/**
 * _init sets all CollectionHandler attributes to their default value. Make sure to
 * call this method within your class constructor
 */
CollectionHandler.prototype._init = function ()
{
  /**
   * 
   */
  this.m_router = "";

  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param name
    *      
 */
CollectionHandler.prototype.create = function (name)
{
  
}


/**
 * 
 */
CollectionHandler.prototype.get = function ()
{
  
}


/**
 * 
 * @param client
    *      
 * @param view
    *      
 * @param model
    *      
 */
CollectionHandler.prototype.modelAndView = function (client, view, model)
{
  
}



