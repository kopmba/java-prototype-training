# coding=System
from com.wazshop.bean.Collection import *

class ApplicationHandler(object):

  """
   

  :version:
  :author:
  """

  def create(self):
    """
     

    @return HttpHandler :
    @author
    """
    pass

  def get(self, id):
    """
     

    @param string id : 
    @return HttpHandler :
    @author
    """
    pass

  def get(self):
    """
     

    @return HttpHandler :
    @author
    """
    pass

  def update(self, id, bean):
    """
     

    @param string id : 
    @param com.wazshop.bean.Collection bean : 
    @return HttpHandler :
    @author
    """
    pass

  def remove(self, id):
    """
     

    @param string id : 
    @return HttpHandler :
    @author
    """
    pass



