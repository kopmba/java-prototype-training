#include "CollectionHandler.h"

// Constructors/Destructors
//  

CollectionHandler::CollectionHandler()
{
  initAttributes();
}

CollectionHandler::~CollectionHandler()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void CollectionHandler::initAttributes()
{
}

