<?php
require_once 'com/wazshop/application/handler/ApplicationHandler.php';
require_once 'com/wazshop/context/Client.php';
require_once 'com/wazshop/config/RouterConfig.php';


/**
 * class CollectionHandler
 * 
 */
class CollectionHandler
      implements ApplicationHandler
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $router;


  /**
   * 
   *
   * @param string name 

   * @return void
   * @access public
   */
  public function create( $name) {
  } // end of member function create

  /**
   * 
   *
   * @return List
   * @access public
   */
  public function get() {
  } // end of member function get

  /**
   * 
   *
   * @param com.wazshop.context::Client client 

   * @param string view 

   * @param object model 

   * @return void
   * @access public
   */
  public function modelAndView( $client,  $view,  $model) {
  } // end of member function modelAndView



  /**
   * 
   *
   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function create();

  /**
   * 
   *
   * @param string id 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function get( $id);

  /**
   * 
   *
   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function get();

  /**
   * 
   *
   * @param string id 

   * @param com.wazshop.bean::Collection bean 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function update( $id,  $bean);

  /**
   * 
   *
   * @param string id 

   * @return HttpHandler
   * @abstract
   * @access public
   */
  abstract public function remove( $id);



} // end of CollectionHandler
?>
