using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using com.wazshop.bean;

namespace com.wazshop.config
{

  /// <summary>
  /// 
  /// </summary>
  public class DBConfig
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private DB DB;



    #endregion


    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="filename"></param>
    /// <returns></returns>
    public void createConnection(string filename)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="options"></param>
    /// <returns></returns>
    public void connect(string[] options)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="filename"></param>
    /// <returns></returns>
    private void config(string filename)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


  }

}  // end of namespace com.wazshop.config

