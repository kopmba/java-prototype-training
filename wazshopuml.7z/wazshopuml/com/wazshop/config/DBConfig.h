
#ifndef DBCONFIG_H
#define DBCONFIG_H

#include <string>


namespace com_wazshop_config {


/**
  * class DBConfig
  * 
  */

class DBConfig
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  DBConfig();

  /**
   * Empty Destructor
   */
  virtual ~DBConfig();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  filename
   */
  void createConnection(std::string filename)
  {
  }


  /**
   * @param  options
   */
  void connect(string options)
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  com.wazshop.bean::DB DB;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of DB
   * @param value the new value of DB
   */
  void setDB(com.wazshop.bean::DB value)
  {
    DB = value;
  }

  /**
   * Get the value of DB
   * @return the value of DB
   */
  com.wazshop.bean::DB getDB()
  {
    return DB;
  }


  /**
   * @param  filename
   */
  void config(std::string filename)
  {
  }

  void initAttributes();

};
} // end of package namespace

#endif // DBCONFIG_H
