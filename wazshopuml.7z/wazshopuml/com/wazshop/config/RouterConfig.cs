using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using com.wazshop.context;

namespace com.wazshop.config
{

  /// <summary>
  /// 
  /// </summary>
  public class RouterConfig
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes


    #endregion


    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="ctx"></param>
    /// <param name="collection"></param>
    /// <param name="method_option"></param>
    /// <returns></returns>
    public void config(Context ctx, string collection, string method_option)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.config

