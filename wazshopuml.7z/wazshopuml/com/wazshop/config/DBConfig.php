<?php
require_once 'com/wazshop/bean/DB.php';
require_once 'string[].php';


/**
 * class DBConfig
 * 
 */
class DBConfig
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $DB;


  /**
   * 
   *
   * @param string filename 

   * @return void
   * @access public
   */
  public function createConnection( $filename) {
  } // end of member function createConnection

  /**
   * 
   *
   * @param string[] options 

   * @return void
   * @access public
   */
  public function connect( $options) {
  } // end of member function connect



  /**
   * 
   *
   * @param string filename 

   * @return void
   * @access private
   */
  private function config( $filename) {
  } // end of member function config



} // end of DBConfig
?>
