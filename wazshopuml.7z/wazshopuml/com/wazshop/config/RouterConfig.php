<?php
require_once 'com/wazshop/context/com/wazshop/context.php';
require_once 'com/wazshop/context/Context.php';


/**
 * class RouterConfig
 * 
 */
class RouterConfig
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/


  /**
   * 
   *
   * @param com.wazshop.context::Context ctx 

   * @param string collection 

   * @param string method_option 

   * @return void
   * @access public
   */
  public function config( $ctx,  $collection,  $method_option) {
  } // end of member function config





} // end of RouterConfig
?>
