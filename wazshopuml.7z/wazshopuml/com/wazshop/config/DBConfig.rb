#
# 
#

class DBConfig
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _filename_ string
  def createConnection(filename)
    
  end

  #
  # 
  # * _options_ string_
  def connect(options)
    
  end

  protected

  private

  #
  # 
  # * _filename_ string
  def config(filename)
    
  end

end

