# coding=System
from com.wazshop.context.com.wazshop.context import *
from com.wazshop.context.Context import *

class RouterConfig(object):

  """
   

  :version:
  :author:
  """

  def config(self, ctx, collection, method_option):
    """
     

    @param com.wazshop.context.Context ctx : 
    @param string collection : 
    @param string method_option : 
    @return  :
    @author
    """
    pass



