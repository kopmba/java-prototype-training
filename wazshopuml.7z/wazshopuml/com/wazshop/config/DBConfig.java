package com.wazshop.config;
import com.wazshop.bean.DB;


/**
 * Class DBConfig
 */
public class DBConfig {

  //
  // Fields
  //

  private com.wazshop.bean.DB DB;
  
  //
  // Constructors
  //
  public DBConfig () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of DB
   * @param newVar the new value of DB
   */
  public void setDB (com.wazshop.bean.DB newVar) {
    DB = newVar;
  }

  /**
   * Get the value of DB
   * @return the value of DB
   */
  public com.wazshop.bean.DB getDB () {
    return DB;
  }

  //
  // Other methods
  //

  /**
   * @param        filename
   */
  public void createConnection(String filename)
  {
  }


  /**
   * @param        options
   */
  public void connect(string[] options)
  {
  }


  /**
   * @param        filename
   */
  private void config(String filename)
  {
  }


}
