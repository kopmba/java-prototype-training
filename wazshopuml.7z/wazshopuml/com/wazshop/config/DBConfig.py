# coding=System
from com.wazshop.bean.DB import *
from string[] import *

class DBConfig(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  DB  (private)

  """

  def createConnection(self, filename):
    """
     

    @param string filename : 
    @return  :
    @author
    """
    pass

  def connect(self, options):
    """
     

    @param string[] options : 
    @return  :
    @author
    """
    pass

  def __config(self, filename):
    """
     

    @param string filename : 
    @return  :
    @author
    """
    pass



