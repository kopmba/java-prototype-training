#include "RouterConfig.h"

// Constructors/Destructors
//  

RouterConfig::RouterConfig()
{
}

RouterConfig::~RouterConfig()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


