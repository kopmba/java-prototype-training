#include "DBConfig.h"

// Constructors/Destructors
//  

DBConfig::DBConfig()
{
  initAttributes();
}

DBConfig::~DBConfig()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void DBConfig::initAttributes()
{
}

