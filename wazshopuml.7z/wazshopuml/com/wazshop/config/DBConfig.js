#include "com/wazshop/bean/DB.js"
#include "string[].js"


/**
  * class DBConfig
  * 
  */

DBConfig = function ()
{
  this._init ();
}


/**
 * _init sets all DBConfig attributes to their default value. Make sure to call
 * this method within your class constructor
 */
DBConfig.prototype._init = function ()
{
  /**
   * 
   */
  this.m_DB = "";

  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param filename
    *      
 */
DBConfig.prototype.config = function (filename)
{
  
}


/**
 * 
 * @param filename
    *      
 */
DBConfig.prototype.createConnection = function (filename)
{
  
}


/**
 * 
 * @param options
    *      
 */
DBConfig.prototype.connect = function (options)
{
  
}



