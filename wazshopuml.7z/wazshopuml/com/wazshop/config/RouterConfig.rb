#
# 
#

class RouterConfig
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _ctx_ com_wazshop_context_Context
  # * _collection_ string
  # * _method_option_ string
  def config(ctx, collection, method_option)
    
  end

  protected

  private

end

