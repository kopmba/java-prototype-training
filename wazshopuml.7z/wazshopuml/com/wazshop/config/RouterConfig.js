#include "com/wazshop/context/com/wazshop/context.js"
#include "com/wazshop/context/Context.js"


/**
  * class RouterConfig
  * 
  */

RouterConfig = function ()
{
  this._init ();
}


/**
 * _init sets all RouterConfig attributes to their default value. Make sure to call
 * this method within your class constructor
 */
RouterConfig.prototype._init = function ()
{

  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param ctx
    *      
 * @param collection
    *      
 * @param method_option
    *      
 */
RouterConfig.prototype.config = function (ctx, collection, method_option)
{
  
}



