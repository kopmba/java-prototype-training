package com.wazshop.config;
import com.wazshop.context.com_wazshop_context;
import com.wazshop.context.Context;


/**
 * Class RouterConfig
 */
public class RouterConfig {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public RouterConfig () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @param        ctx
   * @param        collection
   * @param        method_option
   */
  public void config(com.wazshop.context.Context ctx, String collection, String method_option)
  {
  }


}
