
#ifndef ROUTERCONFIG_H
#define ROUTERCONFIG_H

#include <string>


namespace com_wazshop_config {


/**
  * class RouterConfig
  * 
  */

class RouterConfig
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  RouterConfig();

  /**
   * Empty Destructor
   */
  virtual ~RouterConfig();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  ctx
   * @param  collection
   * @param  method_option
   */
  void config(com.wazshop.context::Context ctx, std::string collection, std::string method_option)
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  


  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // ROUTERCONFIG_H
