<?php
require_once 'List.php';
require_once 'map<string,_List>.php';
require_once 'map<map<string,_List>,_double>.php';


/**
 * class DBTransaction
 * 
 */
interface DBTransaction
{

  /** Aggregations: */

  /** Compositions: */

  /**
   * 
   *
   * @param List data 

   * @return List<map<string, object>>
   * @abstract
   * @access public
   */
  abstract public function collect( $data);

  /**
   * 
   *
   * @param map<string, List> block 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function store( $block);

  /**
   * 
   *
   * @param map<map<string, List>, double> mapOfBlock 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function credit( $mapOfBlock);





} // end of DBTransaction
?>
