package com.wazshop.db.transaction;


/**
 * Interface DBTransaction
 */
public interface DBTransaction {

  //
  // Fields
  //

  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       List<map<string, object>>
   * @param        data
   */
  public List<map<string, object>> collect(List data);


  /**
   * @param        block
   */
  public void store(map<string, List> block);


  /**
   * @param        mapOfBlock
   */
  public void credit(map<map<string, List>, double> mapOfBlock);


}
