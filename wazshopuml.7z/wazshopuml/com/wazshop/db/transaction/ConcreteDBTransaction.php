<?php
require_once 'com/wazshop/db/transaction/DBTransaction.php';
require_once 'com/wazshop/bean/Transaction.php';
require_once 'com/wazshop/db/transaction/ConcreteDBTransaction.php';


/**
 * class ConcreteDBTransaction
 * 
 */
class ConcreteDBTransaction
      implements DBTransaction, DBTransaction
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/

  /**
   * 
   * @access private
   */
  private $transaction;




  /**
   * 
   *
   * @param List data 

   * @return List<map<string, object>>
   * @abstract
   * @access public
   */
  abstract public function collect( $data);

  /**
   * 
   *
   * @param map<string, List> block 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function store( $block);

  /**
   * 
   *
   * @param map<map<string, List>, double> mapOfBlock 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function credit( $mapOfBlock);

  /**
   * 
   *
   * @param List data 

   * @return List<map<string, object>>
   * @abstract
   * @access public
   */
  abstract public function collect( $data);

  /**
   * 
   *
   * @param map<string, List> block 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function store( $block);

  /**
   * 
   *
   * @param map<map<string, List>, double> mapOfBlock 

   * @return void
   * @abstract
   * @access public
   */
  abstract public function credit( $mapOfBlock);



} // end of ConcreteDBTransaction
?>
