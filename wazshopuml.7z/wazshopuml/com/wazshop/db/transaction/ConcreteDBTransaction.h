
#ifndef CONCRETEDBTRANSACTION_H
#define CONCRETEDBTRANSACTION_H

#include "com/wazshop/db/transaction/DBTransaction.h"
#include "com/wazshop/db/transaction/DBTransaction.h"

#include <string>


namespace com_wazshop_db_transaction {


/**
  * class ConcreteDBTransaction
  * 
  */

class ConcreteDBTransaction : virtual public DBTransaction, virtual public DBTransaction
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  ConcreteDBTransaction();

  /**
   * Empty Destructor
   */
  virtual ~ConcreteDBTransaction();

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  com.wazshop.bean::Transaction transaction;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of transaction
   * @param value the new value of transaction
   */
  void setTransaction(com.wazshop.bean::Transaction value)
  {
    transaction = value;
  }

  /**
   * Get the value of transaction
   * @return the value of transaction
   */
  com.wazshop.bean::Transaction getTransaction()
  {
    return transaction;
  }

  void initAttributes();

};
} // end of package namespace

#endif // CONCRETEDBTRANSACTION_H
