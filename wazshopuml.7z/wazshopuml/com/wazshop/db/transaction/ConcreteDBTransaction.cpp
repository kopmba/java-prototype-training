#include "ConcreteDBTransaction.h"

// Constructors/Destructors
//  

ConcreteDBTransaction::ConcreteDBTransaction()
{
  initAttributes();
}

ConcreteDBTransaction::~ConcreteDBTransaction()
{
}

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

void ConcreteDBTransaction::initAttributes()
{
}

