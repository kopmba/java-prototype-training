# coding=System
from List import *
from map<string,_List> import *
from map<map<string,_List>,_double> import *

class DBTransaction(object):

  """
   

  :version:
  :author:
  """

  def collect(self, data):
    """
     

    @param List data : 
    @return List<map<string, object>> :
    @author
    """
    pass

  def store(self, block):
    """
     

    @param map<string, List> block : 
    @return  :
    @author
    """
    pass

  def credit(self, mapOfBlock):
    """
     

    @param map<map<string, List>, double> mapOfBlock : 
    @return  :
    @author
    """
    pass



