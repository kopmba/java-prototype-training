
#ifndef DBTRANSACTION_H
#define DBTRANSACTION_H

#include <string>


namespace com_wazshop_db_transaction {


/**
  * class DBTransaction
  * 
  */

class DBTransaction
{
public:
  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @return List<map<string, object>>
   * @param  data
   */
  virtual List<map<string, object>> collect(List data) = 0;


  /**
   * @param  block
   */
  virtual void store(map<string, List> block) = 0;


  /**
   * @param  mapOfBlock
   */
  virtual void credit(map<map<string, List>, double> mapOfBlock) = 0;

protected:
  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //

};
} // end of package namespace

#endif // DBTRANSACTION_H
