package com.wazshop.db.transaction;
import com.wazshop.bean.Transaction;


/**
 * Class ConcreteDBTransaction
 */
public class ConcreteDBTransaction implements DBTransaction, DBTransaction {

  //
  // Fields
  //

  private com.wazshop.bean.Transaction transaction;
  
  //
  // Constructors
  //
  public ConcreteDBTransaction () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of transaction
   * @param newVar the new value of transaction
   */
  public void setTransaction (com.wazshop.bean.Transaction newVar) {
    transaction = newVar;
  }

  /**
   * Get the value of transaction
   * @return the value of transaction
   */
  public com.wazshop.bean.Transaction getTransaction () {
    return transaction;
  }

  //
  // Other methods
  //

  /**
   * @return       List<map<string, object>>
   * @param        data
   */
  abstract public List<map<string, object>> collect(List data);


  /**
   * @param        block
   */
  abstract public void store(map<string, List> block);


  /**
   * @param        mapOfBlock
   */
  abstract public void credit(map<map<string, List>, double> mapOfBlock);


}
