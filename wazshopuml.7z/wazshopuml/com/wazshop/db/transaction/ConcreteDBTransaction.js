#include "com/wazshop/db/transaction/DBTransaction.js"
#include "com/wazshop/bean/Transaction.js"
#include "com/wazshop/db/transaction/ConcreteDBTransaction.js"


/**
  * class ConcreteDBTransaction
  * 
  */

ConcreteDBTransaction = function ()
{
  this._init ();
}

ConcreteDBTransaction.prototype = new DBTransaction ();
ConcreteDBTransaction.prototype = new DBTransaction ();

/**
 * _init sets all ConcreteDBTransaction attributes to their default value. Make
 * sure to call this method within your class constructor
 */
ConcreteDBTransaction.prototype._init = function ()
{
  /**
   * 
   */
  this.m_transaction = "";

  /**Aggregations: */

  /**Compositions: */

}


