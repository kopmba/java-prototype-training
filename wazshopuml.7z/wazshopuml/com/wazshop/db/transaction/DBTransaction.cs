using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;


namespace com.wazshop.db.transaction
{

  /// <summary>
  /// 
  /// </summary>
  public interface DBTransaction
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Public methods

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns>List<map<string, object>></returns>
    List<map<string, object>> collect(List data);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="block"></param>
    /// <returns></returns>
    void store(map<string, List> block);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mapOfBlock"></param>
    /// <returns></returns>
    void credit(map<map<string, List>, double> mapOfBlock);

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.db.transaction

