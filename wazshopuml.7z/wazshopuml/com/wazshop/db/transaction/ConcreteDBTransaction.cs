using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

using com.wazshop.bean;

namespace com.wazshop.db.transaction
{

  /// <summary>
  /// 
  /// </summary>
  public class ConcreteDBTransaction : , DBTransaction, DBTransaction
  {

    #region Aggregations


    #endregion

    #region Compositions


    #endregion

    #region Attributes

    /// <summary>
    /// 
    /// </summary>
    private Transaction transaction;



    #endregion


    #region DBTransaction members

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns>List<map<string, object>></returns>
    abstract public List<map<string, object>> collect(List data);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="block"></param>
    /// <returns></returns>
    abstract public void store(map<string, List> block);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mapOfBlock"></param>
    /// <returns></returns>
    abstract public void credit(map<map<string, List>, double> mapOfBlock);

    #endregion


    #region DBTransaction members

    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <returns>List<map<string, object>></returns>
    abstract public List<map<string, object>> collect(List data);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="block"></param>
    /// <returns></returns>
    abstract public void store(map<string, List> block);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="mapOfBlock"></param>
    /// <returns></returns>
    abstract public void credit(map<map<string, List>, double> mapOfBlock);

    #endregion


    #region Public methods

    #endregion


    #region Protected methods

    #endregion


    #region Private methods

    #endregion


  }

}  // end of namespace com.wazshop.db.transaction

