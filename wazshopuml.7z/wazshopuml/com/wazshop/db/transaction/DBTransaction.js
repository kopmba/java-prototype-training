#include "List.js"
#include "map<string,_List>.js"
#include "map<map<string,_List>,_double>.js"


/**
  * class DBTransaction
  * 
  */

DBTransaction = function ()
{
  this._init ();
}



  /**Aggregations: */

  /**Compositions: */

}

/**
 * 
 * @param data
    *      
 */
DBTransaction.prototype.collect = function (data)
{
  
}


/**
 * 
 * @param block
    *      
 */
DBTransaction.prototype.store = function (block)
{
  
}


/**
 * 
 * @param mapOfBlock
    *      
 */
DBTransaction.prototype.credit = function (mapOfBlock)
{
  
}



