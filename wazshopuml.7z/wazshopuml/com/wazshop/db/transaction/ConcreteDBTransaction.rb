#
# 
#

class ConcreteDBTransaction < DBTransaction
  include DBTransaction

  #
  # Accessor Methods
  #


  public

  protected

  private

end

