# coding=System
from com_wazshop_db_transaction.DBTransaction import *
from com_wazshop_db_transaction.DBTransaction import *
from com.wazshop.db.transaction.DBTransaction import *
from com.wazshop.bean.Transaction import *
from com.wazshop.db.transaction.ConcreteDBTransaction import *

class ConcreteDBTransaction (DBTransaction, DBTransaction):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  transaction  (private)

  """



