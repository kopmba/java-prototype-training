#
# 
#

class DBTransaction
  #
  # Accessor Methods
  #


  public

  #
  # 
  # * _data_ List
  # * _returns_ List_map_string_object_
  def collect(data)
    
  end

  #
  # 
  # * _block_ map_string_List_
  def store(block)
    
  end

  #
  # 
  # * _mapOfBlock_ map_map_string_List_double_
  def credit(mapOfBlock)
    
  end

  protected

  private

end

